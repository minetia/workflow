import sys
print("▶ [1단계] 파이썬 기본 실행 확인... 정상")

try:
    print("▶ [2단계] 웹 서버 라이브러리(FastAPI) 불러오는 중...")
    from fastapi import FastAPI
    import uvicorn
    print("▶ [3단계] 라이브러리 로딩 완료! 서버 준비 중...")
except Exception as e:
    print(f"❌ 라이브러리 에러 발생: {e}")
    sys.exit()

app = FastAPI()

@app.get("/")
def test_route():
    return {"status": "Phoenix Server is Alive!"}

if __name__ == "__main__":
    print("▶ [4단계] Uvicorn 메인 엔진 점화! (포트 8888)")
    try:
        # reload=True 옵션을 빼서 윈도우 데드락 버그를 원천 차단합니다.
        uvicorn.run(app, host="127.0.0.1", port=8888)
    except Exception as e:
        print(f"❌ 서버 실행 중 치명적 오류: {e}")