"""
Project Phoenix V2 - Risk Manager (자산 보호 방패)
거래 리스크를 관리하고 자산을 보호합니다.
"""

class RiskManager:
    def __init__(self):
        self.max_loss_limit = 0.05  # 단일 거래 최대 손실 5%
        self.total_stop_loss = 0.10 # 총 자산 대비 최대 손실 10%
        self.is_active = True

    def check_trade_safety(self, current_balance, trade_amount):
        """거래 안전성 검사"""
        if not self.is_active:
            return False, "리스크 관리 시스템이 비활성화 상태입니다."
            
        if trade_amount > current_balance * 0.2: # 단일 거래에 자산의 20% 이상 투입 금지
            return False, "단일 거래 한도 초과 (최대 자산의 20%)"
            
        return True, "안전"

    def apply_stop_loss(self, buy_price, current_price):
        """스탑로스 실시간 감시"""
        loss_rate = (current_price - buy_price) / buy_price
        if loss_rate <= -self.max_loss_limit:
            return True, f"스탑로스 발동: 손실률 {loss_rate*100:.2f}%"
        return False, "정상"

    def emergency_stop(self):
        """긴급 정지 시스템 (Panic Switch)"""
        self.is_active = False
        print("[RiskManager] 긴급 정지 발동! 모든 거래가 차단됩니다.")

if __name__ == "__main__":
    rm = RiskManager()
    safe, msg = rm.check_trade_safety(1000000, 300000)
    print(f"거래 검사 결과: {msg}")
