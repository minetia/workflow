"""
Project Phoenix V2 - Exchange API (거래소 주문망)
업비트 및 주요 거래소와의 API 통신을 담당합니다.
"""
import pyupbit
import os
from dotenv import load_dotenv

load_dotenv()

class ExchangeAPI:
    def __init__(self):
        self.access_key = os.getenv("UPBIT_ACCESS_KEY")
        self.secret_key = os.getenv("UPBIT_SECRET_KEY")
        self.upbit = None
        
        if self.access_key and self.secret_key:
            self.upbit = pyupbit.Upbit(self.access_key, self.secret_key)
            print("[ExchangeAPI] API 연결 성공")
        else:
            print("[ExchangeAPI] API 키가 설정되지 않았습니다. (조회 모드)")

    def get_balance(self, ticker="KRW"):
        """잔고 조회"""
        if self.upbit:
            return self.upbit.get_balance(ticker)
        return 0.0

    def buy_market_order(self, ticker, price):
        """시장가 매수"""
        try:
            if self.upbit:
                return self.upbit.buy_market_order(ticker, price)
        except Exception as e:
            print(f"[ExchangeAPI] 매수 에러: {e}")
        return None

    def sell_market_order(self, ticker, volume):
        """시장가 매도"""
        try:
            if self.upbit:
                return self.upbit.sell_market_order(ticker, volume)
        except Exception as e:
            print(f"[ExchangeAPI] 매도 에러: {e}")
        return None

if __name__ == "__main__":
    api = ExchangeAPI()
    print(f"KRW 잔고: {api.get_balance('KRW')}")
