import pyupbit
import time

print("🦅 [Phoenix System] 업비트 통신망 점검을 시작합니다...")
time.sleep(1)

try:
    price = pyupbit.get_current_price("KRW-BTC")
    if price is not None:
        print(f"✅ 통신 성공! 현재 비트코인 가격: {price:,.0f} 원")
    else:
        print("❌ 통신 실패! (가격 정보를 가져오지 못했습니다.)")
except Exception as e:
    print(f"❌ 치명적 오류 발생! 원인: {e}")