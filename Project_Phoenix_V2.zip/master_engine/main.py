from fastapi import FastAPI, Request, WebSocket
from fastapi.templating import Jinja2Templates
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
import pyupbit
import asyncio
import os

app = FastAPI(title="Project Phoenix V2 - Original")

# 순정 경로 설정
current_dir = os.path.dirname(os.path.abspath(__file__))
assets_dir = os.path.join(os.path.dirname(current_dir), "quantum_assets")
app.mount("/assets", StaticFiles(directory=assets_dir), name="assets")
templates = Jinja2Templates(directory=assets_dir)

# V2 Portfolio (2월 22일 기준 순정 자산)
V2_PORTFOLIO = [
    {"code": "KRW-BTC",  "name": "Bitcoin",   "qty": 0.02, "avg": 139000000},
    {"code": "KRW-ETH",  "name": "Ethereum",  "qty": 0.61, "avg": 4700000},
    {"code": "KRW-SOL",  "name": "Solana",    "qty": 7.00, "avg": 193000},
    {"code": "KRW-ZRX",  "name": "0x",        "qty": 39624, "avg": 357},
    {"code": "KRW-ONDO", "name": "Ondo",      "qty": 627, "avg": 478}
]

@app.get("/", response_class=HTMLResponse)
async def read_root(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})

@app.websocket("/ws/quantum")
async def websocket_endpoint(websocket: WebSocket):
    await websocket.accept()
    print("🟢 [System] 순정 엔진 통신 시작")
    tickers = [item["code"] for item in V2_PORTFOLIO]
    while True:
        try:
            prices = await asyncio.to_thread(pyupbit.get_current_price, tickers)
            if prices:
                data = [{"symbol": k, "cur_price": v} for k, v in prices.items()]
                await websocket.send_json({"type": "update", "data": data})
            await asyncio.sleep(1)
        except: break

if __name__ == "__main__":
    import uvicorn
    # 마법사의 8888 포트를 버리고 8899로 우회합니다.
    uvicorn.run(app, host="127.0.0.1", port=8899)