"""
Project Phoenix V2 - Data Collector (시장 정찰병)
실시간 및 과거 시장 데이터를 수집하여 전략에 전달합니다.
"""
import pyupbit
import pandas as pd
import time

class DataCollector:
    def __init__(self):
        self.data_cache = {}

    def fetch_ohlcv(self, ticker="KRW-BTC", interval="minute1", count=200):
        """캔들 데이터 수집"""
        try:
            df = pyupbit.get_ohlcv(ticker, interval=interval, count=count)
            return df
        except Exception as e:
            print(f"[DataCollector] 데이터 수집 에러: {e}")
            return None

    def calculate_technical_indicators(self, df):
        """기술적 지표 계산 (예: 이동평균선)"""
        if df is not None:
            df['ma5'] = df['close'].rolling(window=5).mean()
            df['ma20'] = df['close'].rolling(window=20).mean()
        return df

    def get_realtime_signal(self, ticker):
        """실시간 정찰 신호 추출"""
        df = self.fetch_ohlcv(ticker, count=20)
        df = self.calculate_technical_indicators(df)
        
        if df is not None:
            last_row = df.iloc[-1]
            return {
                "ticker": ticker,
                "price": last_row['close'],
                "ma5": last_row['ma5'],
                "ma20": last_row['ma20']
            }
        return None

if __name__ == "__main__":
    collector = DataCollector()
    signal = collector.get_realtime_signal("KRW-BTC")
    print(f"BTC 정찰 데이터: {signal}")
