import pandas as pd
class Strategy:
    pass
